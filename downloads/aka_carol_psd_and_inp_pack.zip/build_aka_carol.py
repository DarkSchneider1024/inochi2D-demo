# -*- coding: utf-8 -*-
import copy, io, json, math, os, struct, zipfile
import cv2
import numpy as np
from PIL import Image, ImageDraw

WORK = '/working_dir/c_049b8b64f4523031'
AKA_INP = os.path.join(WORK, 'downloads/aka.inp')
CAROL_DIR = os.path.join(WORK, 'extracted/carol')
GEM_DIR = os.path.join(WORK, 'extracted/gemini')
OUT_DIR = os.path.join(WORK, 'output_drive')
DEMO_DIR = os.path.join(WORK, 'demo_build')
os.makedirs(OUT_DIR, exist_ok=True)

# 1. Load aka.inp with exact raw PNG bytes preserved
raw_bytes = open(AKA_INP, 'rb').read()
j_len = struct.unpack('>I', raw_bytes[8:12])[0]
j_base = json.loads(raw_bytes[12:12 + j_len].decode('utf-8'))
o = 12 + j_len + 8
cnt = struct.unpack('>I', raw_bytes[o:o + 4])[0]
o += 4
raw_pngs = []
orig_texs = []
for i in range(cnt):
    L = struct.unpack('>I', raw_bytes[o:o + 4])[0]
    pbytes = raw_bytes[o + 5:o + 5 + L]
    raw_pngs.append(pbytes)
    orig_texs.append(Image.open(io.BytesIO(pbytes)).convert('RGBA'))
    o += 5 + L

def unpremult_pil(im_pil):
    arr = np.array(im_pil.convert('RGBA')).astype(np.float32)
    a = arr[..., 3:4]
    rgb = np.where(a > 0, np.clip(arr[..., :3] * 255.0 / np.maximum(1.0, a), 0, 255), 0)
    return Image.fromarray(np.dstack([rgb.round().astype(np.uint8), arr[..., 3].astype(np.uint8)]), 'RGBA')

def to_compact_premult_png(im_pil, max_dim=1100, colors=256):
    """Quantize straight RGBA to 256 colors, convert back to RGBA, premultiply by smooth alpha,
    and clamp R,G,B <= A so over_total == 0 (100% premultiplied, zero double-alpha) and file size is compact."""
    im = im_pil.convert('RGBA')
    W, H = im.size
    if max(W, H) > max_dim and W > 16:
        sc = max_dim / float(max(W, H))
        im = im.resize((max(1, int(round(W * sc))), max(1, int(round(H * sc)))), Image.LANCZOS)
    arr = np.array(im)
    if arr[..., 3].max() == 0:
        ok, enc = cv2.imencode('.png', np.zeros((16, 16, 4), np.uint8))
        return enc.tobytes()
    orig_a = arr[..., 3:4].astype(np.float32)
    rgb_p = np.round(arr[..., :3].astype(np.float32) * (orig_a / 255.0))
    rgb_p = np.minimum(rgb_p, orig_a).astype(np.uint8)
    premult_im = Image.fromarray(np.dstack([rgb_p, arr[..., 3]]), 'RGBA')
    # Quantize the premultiplied RGBA to 256 colors, then fix any palette entries where R,G,B > A!
    q = premult_im.quantize(colors=colors, method=Image.FASTOCTREE, dither=Image.Dither.NONE).convert('RGBA')
    q_arr = np.array(q)
    qa = q_arr[..., 3:4]
    q_rgb = np.minimum(q_arr[..., :3], qa)
    fixed = Image.fromarray(np.dstack([q_rgb, q_arr[..., 3]]), 'RGBA')
    buf = io.BytesIO()
    fixed.save(buf, 'PNG', optimize=True, compress_level=9)
    return buf.getvalue()

def clean_white_bg_crop(rgb_arr, border_seeds=True, strip_All_white=False):
    ch, cw, _ = rgb_arr.shape
    bg_cand = ((rgb_arr.min(axis=-1) > 235) & ((rgb_arr.max(axis=-1).astype(int) - rgb_arr.min(axis=-1).astype(int)) < 22)).astype(np.uint8)
    if border_seeds and not strip_All_white:
        n_bg, l_bg = cv2.connectedComponents(bg_cand, connectivity=4)
        border_labels = set(l_bg[0, :]) | set(l_bg[-1, :]) | set(l_bg[:, 0]) | set(l_bg[:, -1])
        border_labels.discard(0)
        ext_mask = np.isin(l_bg, list(border_labels))
    else:
        ext_mask = bg_cand > 0

    fg = (~ext_mask).astype(np.uint8)
    n_fg, l_fg, stats, _ = cv2.connectedComponentsWithStats(fg, connectivity=8)
    if n_fg > 1:
        largest = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
        fg = (l_fg == largest).astype(np.uint8)
        ext_mask = fg == 0

    dist = cv2.distanceTransform(fg, cv2.DIST_L2, 3)
    alpha = fg.astype(np.float32) * 255.0
    rim = (dist > 0) & (dist <= 1.8)
    lum = rgb_arr.mean(axis=-1)
    rim_a = np.clip((250.0 - lum[rim]) / 35.0, 0.0, 1.0)
    alpha[rim] = np.minimum(alpha[rim], rim_a * 255.0)
    alpha = cv2.GaussianBlur(alpha, (3, 3), 0.45)
    alpha[ext_mask] = 0.0

    rgb_clean = rgb_arr.copy()
    interior = (dist > 2.0).astype(np.uint8)
    if interior.any() and (1 - interior).any():
        rgb_inpainted = cv2.inpaint(rgb_clean, 1 - interior, 3, cv2.INPAINT_TELEA)
        rim_blend = np.clip((2.2 - dist) / 2.2, 0.0, 1.0)[..., None]
        rgb_clean = (rgb_clean.astype(np.float32) * (1.0 - rim_blend * 0.75) + rgb_inpainted.astype(np.float32) * (rim_blend * 0.75)).astype(np.uint8)

    ys, xs = np.nonzero(alpha > 4)
    if len(ys) == 0:
        return Image.fromarray(np.dstack([rgb_clean, alpha.astype(np.uint8)]), 'RGBA')
    pad = 4
    y0, y1 = max(0, ys.min() - pad), min(ch, ys.max() + 1 + pad)
    x0, x1 = max(0, xs.min() - pad), min(cw, xs.max() + 1 + pad)
    out = np.dstack([rgb_clean[y0:y1, x0:x1], alpha[y0:y1, x0:x1].astype(np.uint8)])
    return Image.fromarray(out, 'RGBA')

def extract_sheet_parts(img_path, min_area=800, strip_all_white=False):
    arr = np.array(Image.open(img_path).convert('RGB'))
    H, W, _ = arr.shape
    non_white = (arr.min(axis=-1) < 240) | ((255 - arr).max(axis=-1) > 16)
    closed = cv2.morphologyEx(non_white.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    num, labels, stats, centroids = cv2.connectedComponentsWithStats(closed, connectivity=8)
    comps = []
    for i in range(1, num):
        x, y, w, h, area = stats[i]
        if area < min_area:
            continue
        pad = 10
        x0, y0 = max(0, x - pad), max(0, y - pad)
        x1, y1 = min(W, x + w + pad), min(H, y + h + pad)
        crop = arr[y0:y1, x0:x1].copy()
        rgba = clean_white_bg_crop(crop, border_seeds=not strip_all_white, strip_All_white=strip_all_white)
        comps.append({'box': (x, y, w, h), 'rgba': rgba})
    comps.sort(key=lambda c: (int(c['box'][1] // 300), c['box'][0]))
    return comps

def get_part_nodes_and_world(j):
    parts = {}
    def walk(nd, pxy=(0.0, 0.0)):
        tx, ty = nd['transform']['trans'][:2]
        wxy = (pxy[0] + tx, pxy[1] + ty)
        if nd.get('type') == 'Part':
            tid = nd['textures'][0]
            parts[tid] = (nd, wxy)
        for c in nd.get('children', []):
            walk(c, wxy)
    walk(j['nodes'])
    return parts

def remesh_part_full_rect(j, tid, new_world_box, grid_nx=9, grid_ny=13, phys_tip_gain=None, yaw_tip_atten=None):
    parts = get_part_nodes_and_world(j)
    node, (tx_w, ty_w) = parts[tid]
    v_orig = np.array(node['mesh']['verts'], dtype=np.float32).reshape(-1, 2)
    w_orig = v_orig + np.array([tx_w, ty_w], dtype=np.float32)
    wx0_o, wy0_o = w_orig.min(axis=0)
    wx1_o, wy1_o = w_orig.max(axis=0)
    u_orig = (w_orig[:, 0] - wx0_o) / max(1.0, float(wx1_o - wx0_o))
    v_orig_n = (w_orig[:, 1] - wy0_o) / max(1.0, float(wy1_o - wy0_o))

    wx0, wy0, wx1, wy1 = new_world_box
    us = np.linspace(0.0, 1.0, grid_nx, dtype=np.float32)
    vs = np.linspace(0.0, 1.0, grid_ny, dtype=np.float32)
    uu, vv = np.meshgrid(us, vs)
    u_new = uu.ravel()
    v_new = vv.ravel()

    wx_new = wx0 + u_new * (wx1 - wx0)
    wy_new = wy0 + v_new * (wy1 - wy0)
    lx_new = wx_new - tx_w
    ly_new = wy_new - ty_w

    verts_new = np.column_stack([lx_new, ly_new]).ravel().round(3).tolist()
    uvs_new = np.column_stack([u_new, v_new]).ravel().round(4).tolist()
    indices_new = []
    for r in range(grid_ny - 1):
        for c in range(grid_nx - 1):
            i0 = r * grid_nx + c
            i1 = i0 + 1
            i2 = i0 + grid_nx
            i3 = i2 + 1
            indices_new.extend([i0, i1, i2, i1, i3, i2])

    node['mesh']['verts'] = verts_new
    node['mesh']['uvs'] = uvs_new
    node['mesh']['indices'] = indices_new

    dist2 = (u_new[:, None] - u_orig[None, :]) ** 2 + (v_new[:, None] - v_orig_n[None, :]) ** 2 + 0.04
    W_mat = 1.0 / (dist2 ** 1.5)
    W_mat /= W_mat.sum(axis=1, keepdims=True)

    uid = node['uuid']
    for p in j['param']:
        pname = p['name']
        for bd in p['bindings']:
            if bd['node'] == uid and bd['param_name'] == 'deform':
                vals = bd['values']
                for ix in range(len(vals)):
                    for iy in range(len(vals[ix])):
                        d_orig = np.array(vals[ix][iy], dtype=np.float32)
                        if len(d_orig) != len(v_orig):
                            continue
                        d_new = W_mat @ d_orig
                        if phys_tip_gain is not None and 'Physics' in pname:
                            scale = (0.15 + phys_tip_gain * (v_new ** 1.25))[:, None]
                            d_new = d_new * scale
                        if yaw_tip_atten is not None and 'Yaw-Pitch' in pname:
                            scale = (1.0 - yaw_tip_atten * (v_new ** 1.1))[:, None]
                            d_new = d_new * scale
                        vals[ix][iy] = d_new.round(3).tolist()

def place_rgba_in_canvas(rgba_pil, target_size, fit_mode='stretch', pad_frac=(0.0, 0.0, 0.0, 0.0), rot_deg=0.0):
    W, H = target_size
    im = rgba_pil.convert('RGBA')
    if abs(rot_deg) > 0.1:
        im = im.rotate(rot_deg, resample=Image.BICUBIC, expand=True)
    arr = np.array(im)
    ys, xs = np.nonzero(arr[..., 3] > 8)
    if len(ys) > 0:
        im = im.crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
    l_pad, t_pad, r_pad, b_pad = pad_frac
    x0 = int(round(W * l_pad))
    y0 = int(round(H * t_pad))
    x1 = max(x0 + 4, int(round(W * (1.0 - r_pad))))
    y1 = max(y0 + 4, int(round(H * (1.0 - b_pad))))
    box_w, box_h = x1 - x0, y1 - y0
    if fit_mode == 'contain':
        scale = min(box_w / max(1, im.width), box_h / max(1, im.height))
        nw, nh = max(1, int(round(im.width * scale))), max(1, int(round(im.height * scale)))
        resized = im.resize((nw, nh), Image.LANCZOS)
        canvas = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        canvas.paste(resized, (x0 + (box_w - nw) // 2, y0 + (box_h - nh) // 2))
        return canvas
    else:
        resized = im.resize((box_w, box_h), Image.LANCZOS)
        canvas = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        canvas.paste(resized, (x0, y0))
        return canvas

# Extract Sister Carol components
hair_comps = extract_sheet_parts(os.path.join(CAROL_DIR, 'carol_hair_parts_white_bg.jpg'), min_area=800, strip_all_white=True)
body_comps = extract_sheet_parts(os.path.join(CAROL_DIR, 'carol_body_parts_white_bg.jpg'), min_area=800, strip_all_white=False)
char_rgb = np.array(Image.open(os.path.join(CAROL_DIR, 'carol_character_white_bg.jpg')).convert('RGB'))

def extract_clean_twintails(char_rgb):
    poly_r = np.array([
        [55, 132], [356, 132], [344, 175], [344, 225], [368, 260],
        [310, 440], [189, 540], [189, 560], [295, 680], [320, 865], [55, 865]
    ], np.int32)
    mask_r = np.zeros(char_rgb.shape[:2], np.uint8)
    cv2.fillPoly(mask_r, [poly_r], 255)
    tw_r = char_rgb.copy()
    tw_r[mask_r == 0] = 255
    top_slice = tw_r[:165, :]
    green_leaf = top_slice[..., 1].astype(int) > (top_slice[..., 0].astype(int) + 5)
    top_slice[green_leaf] = 255
    im_r = clean_white_bg_crop(tw_r[132:865, 55:370], border_seeds=False, strip_All_white=True)
    im_l = im_r.transpose(Image.FLIP_LEFT_RIGHT)
    return im_r, im_l

twintail_r, twintail_l = extract_clean_twintails(char_rgb)
hp_r_crop = char_rgb[148:228, 333:374].copy()
hp_r = clean_white_bg_crop(hp_r_crop, border_seeds=False, strip_All_white=True)
hp_l = hp_r.transpose(Image.FLIP_LEFT_RIGHT)

def make_sailor_arm_texture(sleeve_rgba, target_size, is_right_arm=True):
    W, H = target_size
    canvas = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    if is_right_arm:
        p_sh_top = (430, 60); p_sh_bot = (545, 155)
        p_el_top = (255, 650); p_el_bot = (365, 710)
        p_wr_top = (55, 1210); p_wr_bot = (155, 1275)
        slv_rot = -24.0; slv_box = (210, 15, 595, 760)
    else:
        p_sh_top = (235, 60); p_sh_bot = (120, 155)
        p_el_top = (445, 610); p_el_bot = (335, 670)
        p_wr_top = (695, 1110); p_wr_bot = (595, 1175)
        slv_rot = 26.0; slv_box = (80, 15, 485, 750)

    arm_poly = [p_sh_top, p_el_top, p_wr_top, p_wr_bot, p_el_bot, p_sh_bot]
    ss = 2
    c_ss = Image.new('RGBA', (W * ss, H * ss), (0, 0, 0, 0))
    d_ss = ImageDraw.Draw(c_ss)
    poly_ss = [(x * ss, y * ss) for (x, y) in arm_poly]
    d_ss.polygon(poly_ss, fill=(255, 232, 214, 255))
    shade_poly = [
        ((p_sh_top[0]*3 + p_sh_bot[0]*7)//10 * ss, (p_sh_top[1]*3 + p_sh_bot[1]*7)//10 * ss),
        ((p_el_top[0]*3 + p_el_bot[0]*7)//10 * ss, (p_el_top[1]*3 + p_el_bot[1]*7)//10 * ss),
        ((p_wr_top[0]*3 + p_wr_bot[0]*7)//10 * ss, (p_wr_top[1]*3 + p_wr_bot[1]*7)//10 * ss),
        (p_wr_bot[0] * ss, p_wr_bot[1] * ss),
        (p_el_bot[0] * ss, p_el_bot[1] * ss),
        (p_sh_bot[0] * ss, p_sh_bot[1] * ss),
    ]
    d_ss.polygon(shade_poly, fill=(244, 204, 182, 255))
    d_ss.line([poly_ss[0], poly_ss[1], poly_ss[2]], fill=(58, 34, 24, 255), width=7 * ss)
    d_ss.line([poly_ss[5], poly_ss[4], poly_ss[3]], fill=(58, 34, 24, 255), width=7 * ss)
    arm_im = c_ss.resize((W, H), Image.LANCZOS)
    canvas.alpha_composite(arm_im)

    s_arr = np.array(sleeve_rgba.convert('RGBA'))
    sh, sw, _ = s_arr.shape
    s_crop = Image.fromarray(s_arr[int(sh * 0.20):, :, :], 'RGBA')
    s_rot = s_crop.rotate(slv_rot, resample=Image.BICUBIC, expand=True)
    sr_arr = np.array(s_rot)
    ys, xs = np.nonzero(sr_arr[..., 3] > 8)
    if len(ys) > 0:
        s_rot = s_rot.crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
    bx0, by0, bx1, by1 = slv_box
    s_placed = s_rot.resize((bx1 - bx0, by1 - by0), Image.LANCZOS)
    canvas.alpha_composite(s_placed, (bx0, by0))
    return canvas

j_carol = copy.deepcopy(j_base)
carol_straight_texs = [unpremult_pil(im) for im in orig_texs]
modified_tids = set()

crown_src = np.array(hair_comps[10]['rgba'])
ch_h, ch_w, _ = crown_src.shape
crown_top = Image.fromarray(crown_src[:int(ch_h * 0.65), int(ch_w * 0.12):int(ch_w * 0.88)], 'RGBA')
crown_arr = np.array(crown_top.convert('RGBA')).astype(np.float32)
ch, cw, _ = crown_arr.shape
fade_y = np.clip((0.85 - np.linspace(0, 1, ch)[:, None]) / 0.25, 0.0, 1.0)
crown_arr[..., 3] *= fade_y
crown_feathered = Image.fromarray(crown_arr.round().astype(np.uint8), 'RGBA')

# 57 & 59 cover only upper crown above eyebrows (-2150 .. -1820)
carol_straight_texs[57] = place_rgba_in_canvas(crown_feathered, (280, 340), fit_mode='stretch', pad_frac=(0.02, 0.02, 0.02, 0.05))
remesh_part_full_rect(j_carol, 57, (-430.0, -2150.0, -70.0, -1820.0))
modified_tids.add(57)

carol_straight_texs[59] = place_rgba_in_canvas(crown_feathered, (280, 340), fit_mode='stretch', pad_frac=(0.02, 0.02, 0.02, 0.05))
remesh_part_full_rect(j_carol, 59, (-100.0, -2150.0, 260.0, -1820.0))
modified_tids.add(59)

carol_straight_texs[61] = place_rgba_in_canvas(hair_comps[1]['rgba'], (340, 560), fit_mode='stretch', pad_frac=(0.02, 0.02, 0.02, 0.02))
remesh_part_full_rect(j_carol, 61, (-445.0, -2145.0, -105.0, -1535.0))
modified_tids.add(61)

carol_straight_texs[63] = place_rgba_in_canvas(hair_comps[2]['rgba'], (350, 560), fit_mode='stretch', pad_frac=(0.02, 0.02, 0.02, 0.02))
remesh_part_full_rect(j_carol, 63, (-75.0, -2145.0, 275.0, -1535.0))
modified_tids.add(63)

carol_straight_texs[65] = place_rgba_in_canvas(hair_comps[0]['rgba'], (240, 520), fit_mode='stretch', pad_frac=(0.04, 0.02, 0.04, 0.02))
remesh_part_full_rect(j_carol, 65, (-205.0, -2140.0, 35.0, -1565.0))
modified_tids.add(65)

carol_straight_texs[55] = place_rgba_in_canvas(hair_comps[3]['rgba'], (310, 820), fit_mode='stretch', pad_frac=(0.02, 0.02, 0.02, 0.02))
remesh_part_full_rect(j_carol, 55, (-495.0, -2085.0, -185.0, -1245.0))
modified_tids.add(55)

carol_straight_texs[70] = place_rgba_in_canvas(hair_comps[4]['rgba'], (310, 820), fit_mode='stretch', pad_frac=(0.02, 0.02, 0.02, 0.02))
remesh_part_full_rect(j_carol, 70, (15.0, -2085.0, 325.0, -1245.0))
modified_tids.add(70)

carol_straight_texs[69] = place_rgba_in_canvas(hair_comps[5]['rgba'], (260, 360), fit_mode='contain', pad_frac=(0.04, 0.04, 0.04, 0.02))
remesh_part_full_rect(j_carol, 69, (-205.0, -2445.0, 55.0, -2065.0))
modified_tids.add(69)

carol_straight_texs[52] = place_rgba_in_canvas(hair_comps[8]['rgba'], (420, 620), fit_mode='contain', pad_frac=(0.03, 0.03, 0.03, 0.03), rot_deg=-14.0)
remesh_part_full_rect(j_carol, 52, (-650.0, -2420.0, -210.0, -1800.0))
modified_tids.add(52)

carol_straight_texs[51] = place_rgba_in_canvas(hair_comps[9]['rgba'], (420, 620), fit_mode='contain', pad_frac=(0.03, 0.03, 0.03, 0.03), rot_deg=14.0)
remesh_part_full_rect(j_carol, 51, (40.0, -2420.0, 480.0, -1800.0))
modified_tids.add(51)

carol_straight_texs[49] = place_rgba_in_canvas(hp_r, (200, 420), fit_mode='stretch', pad_frac=(0.05, 0.05, 0.05, 0.05))
remesh_part_full_rect(j_carol, 49, (-525.0, -1920.0, -345.0, -1480.0))
modified_tids.add(49)

carol_straight_texs[48] = place_rgba_in_canvas(hp_l, (200, 420), fit_mode='stretch', pad_frac=(0.05, 0.05, 0.05, 0.05))
remesh_part_full_rect(j_carol, 48, (175.0, -1920.0, 355.0, -1480.0))
modified_tids.add(48)

carol_straight_texs[46] = place_rgba_in_canvas(twintail_r, (540, 1280), fit_mode='contain', pad_frac=(0.02, 0.01, 0.02, 0.02), rot_deg=-5.0)
remesh_part_full_rect(j_carol, 46, (-1290.0, -2020.0, -250.0, 740.0), grid_nx=10, grid_ny=18, phys_tip_gain=1.6, yaw_tip_atten=0.35)
modified_tids.add(46)

carol_straight_texs[47] = place_rgba_in_canvas(twintail_l, (540, 1280), fit_mode='contain', pad_frac=(0.02, 0.01, 0.02, 0.02), rot_deg=5.0)
remesh_part_full_rect(j_carol, 47, (80.0, -2020.0, 1120.0, 740.0), grid_nx=10, grid_ny=18, phys_tip_gain=1.6, yaw_tip_atten=0.35)
modified_tids.add(47)

bh_arr = np.array(hair_comps[10]['rgba'])
bh_h, bh_w, _ = bh_arr.shape
bh_dome = Image.fromarray(bh_arr[int(bh_h * 0.08):, int(bh_w * 0.12):int(bh_w * 0.88)], 'RGBA')
carol_straight_texs[45] = place_rgba_in_canvas(bh_dome, orig_texs[45].size, fit_mode='stretch', pad_frac=(0.04, 0.02, 0.04, 0.05))
remesh_part_full_rect(j_carol, 45, (-540.0, -2150.0, 370.0, -1240.0))
modified_tids.add(45)

for tid in [13, 14, 15, 16, 17, 18, 19, 50, 53, 54, 56, 58, 60, 62, 64, 66, 71]:
    carol_straight_texs[tid] = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    modified_tids.add(tid)

# Face (12): keep peach forehead skin up to v=0.23, only tinting top hairline rim (v < 0.23)
face_straight = np.array(unpremult_pil(orig_texs[12])).astype(np.float32)
fh, fw, _ = face_straight.shape
yy, xx = np.mgrid[0:fh, 0:fw]
u = (xx - fw * 0.5) / (fw * 0.5)
v = yy / float(fh)
ell = np.sqrt((u / 0.62) ** 2 + ((v - 0.64) / 0.36) ** 2)
cap_w = np.clip((ell - 0.90) / 0.10, 0.0, 1.0) * np.clip((0.23 - v) / 0.06, 0.0, 1.0)
lum = (face_straight[..., 0] * 0.299 + face_straight[..., 1] * 0.587 + face_straight[..., 2] * 0.114) / 225.0
orange_rgb = np.stack([
    np.clip(246.0 * lum, 0, 255),
    np.clip(132.0 * lum, 0, 255),
    np.clip(36.0 * lum, 0, 255),
], axis=-1)
w3 = cap_w[..., None]
face_straight[..., :3] = face_straight[..., :3] * (1.0 - w3) + orange_rgb * w3
carol_straight_texs[12] = Image.fromarray(face_straight.round().astype(np.uint8), 'RGBA')
modified_tids.add(12)

neck_straight = np.array(unpremult_pil(orig_texs[10])).astype(np.float32)
n_lum = neck_straight[..., :3].mean(axis=-1)
choker_mask = (neck_straight[..., 3] > 40) & (n_lum < 95.0)
if choker_mask.any():
    c_ratio = np.clip(n_lum[choker_mask] / 60.0, 0.25, 1.15)
    neck_straight[choker_mask, 0] = np.clip(85.0 * c_ratio, 30, 130)
    neck_straight[choker_mask, 1] = np.clip(185.0 * c_ratio, 65, 225)
    neck_straight[choker_mask, 2] = np.clip(75.0 * c_ratio, 25, 115)
carol_straight_texs[10] = Image.fromarray(neck_straight.round().astype(np.uint8), 'RGBA')
modified_tids.add(10)

carol_straight_texs[5] = place_rgba_in_canvas(body_comps[0]['rgba'], orig_texs[5].size, fit_mode='stretch', pad_frac=(0.02, 0.0, 0.02, 0.02))
remesh_part_full_rect(j_carol, 5, (-455.0, -1265.0, 285.0, -310.0))
modified_tids.add(5)

carol_straight_texs[4] = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
modified_tids.add(4)

carol_straight_texs[0] = place_rgba_in_canvas(body_comps[2]['rgba'], orig_texs[0].size, fit_mode='stretch', pad_frac=(0.04, 0.02, 0.04, 0.04))
remesh_part_full_rect(j_carol, 0, (-830.0, -520.0, 670.0, 320.0))
modified_tids.add(0)

carol_straight_texs[1] = place_rgba_in_canvas(body_comps[6]['rgba'], orig_texs[1].size, fit_mode='stretch', pad_frac=(0.05, 0.15, 0.05, 0.10))
remesh_part_full_rect(j_carol, 1, (-840.0, 120.0, 680.0, 460.0))
modified_tids.add(1)

carol_straight_texs[2] = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
modified_tids.add(2)

carol_straight_texs[3] = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
modified_tids.add(3)

carol_straight_texs[8] = make_sailor_arm_texture(body_comps[4]['rgba'], orig_texs[8].size, is_right_arm=True)
remesh_part_full_rect(j_carol, 8, (-888.0, -1167.5, -286.0, 1061.5))
modified_tids.add(8)

carol_straight_texs[6] = make_sailor_arm_texture(body_comps[5]['rgba'], orig_texs[6].size, is_right_arm=False)
remesh_part_full_rect(j_carol, 6, (45.5, -1178.5, 816.5, 988.5))
modified_tids.add(6)

carol_straight_texs[9] = place_rgba_in_canvas(body_comps[9]['rgba'], orig_texs[9].size, fit_mode='contain', pad_frac=(0.02, 0.02, 0.02, 0.02), rot_deg=-15.0)
modified_tids.add(9)

carol_straight_texs[7] = place_rgba_in_canvas(body_comps[10]['rgba'], orig_texs[7].size, fit_mode='contain', pad_frac=(0.02, 0.02, 0.02, 0.02), rot_deg=15.0)
modified_tids.add(7)

carol_straight_texs[74] = place_rgba_in_canvas(body_comps[7]['rgba'], orig_texs[74].size, fit_mode='stretch', pad_frac=(0.08, 0.01, 0.08, 0.01))
remesh_part_full_rect(j_carol, 74, (-520.0, -320.0, -90.0, 2435.0))
modified_tids.add(74)

carol_straight_texs[72] = place_rgba_in_canvas(body_comps[8]['rgba'], orig_texs[72].size, fit_mode='stretch', pad_frac=(0.08, 0.01, 0.08, 0.01))
remesh_part_full_rect(j_carol, 72, (-70.0, -320.0, 360.0, 2435.0))
modified_tids.add(72)

for tid in [73, 75]:
    carol_straight_texs[tid] = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    modified_tids.add(tid)

j_carol['meta']['name'] = '卡洛兒姐姐 (Aka 九軸 × Gemini 換裝版)'
j_carol['meta']['version'] = '2026-11-05-aka-carol-v2'
js_bytes = json.dumps(j_carol, ensure_ascii=False, separators=(',', ':')).encode('utf-8')

out_chunks = [b'TRNSRTS\x00', struct.pack('>I', len(js_bytes)), js_bytes, b'TEX_SECT', struct.pack('>I', len(carol_straight_texs))]
for tid in range(len(carol_straight_texs)):
    if tid not in modified_tids:
        pdata = raw_pngs[tid]
    elif tid in [10, 12]:
        pdata = to_compact_premult_png(carol_straight_texs[tid], max_dim=1024, colors=256)
    else:
        pdata = to_compact_premult_png(carol_straight_texs[tid], max_dim=720, colors=256)
    out_chunks += [struct.pack('>I', len(pdata)), b'\x00', pdata]

inp_bytes = b''.join(out_chunks)
out_inp_path = os.path.join(OUT_DIR, 'aka_carol.inp')
with open(out_inp_path, 'wb') as f:
    f.write(inp_bytes)
with open(os.path.join(OUT_DIR, 'aka_carol.inx'), 'wb') as f:
    f.write(inp_bytes)
print(f"Compact aka_carol.inp size: {len(inp_bytes)/1024:.1f} KB")

# Also fix aka_gemini.inp premultiplied alpha so aka_gemini has 0% over_total too!
gem_inp_orig = os.path.join(GEM_DIR, 'aka_gemini.inp')
if os.path.exists(gem_inp_orig):
    bg = open(gem_inp_orig, 'rb').read()
    ng = struct.unpack('>I', bg[8:12])[0]
    jg = json.loads(bg[12:12+ng].decode('utf-8'))
    og = 12 + ng + 8
    cntg = struct.unpack('>I', bg[og:og+4])[0]
    og += 4
    g_chunks = [b'TRNSRTS\x00', struct.pack('>I', ng), bg[12:12+ng], b'TEX_SECT', struct.pack('>I', cntg)]
    face_tids = {10, 11, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 67, 68}
    for tid in range(cntg):
        Lg = struct.unpack('>I', bg[og:og+4])[0]
        p_raw = bg[og+5:og+5+Lg]
        og += 5 + Lg
        if tid in face_tids:
            pdata = raw_pngs[tid]
        else:
            im_g = Image.open(io.BytesIO(p_raw)).convert('RGBA')
            pdata = to_compact_premult_png(im_g, max_dim=720, colors=256)
        g_chunks += [struct.pack('>I', len(pdata)), b'\x00', pdata]
    gem_fixed_bytes = b''.join(g_chunks)
    with open(os.path.join(OUT_DIR, 'aka_gemini.inp'), 'wb') as f:
        f.write(gem_fixed_bytes)
    with open(os.path.join(OUT_DIR, 'aka_gemini.inx'), 'wb') as f:
        f.write(gem_fixed_bytes)
    print(f"Compact aka_gemini.inp size: {len(gem_fixed_bytes)/1024:.1f} KB")

# Verify 0% over_total on both models and render the updated aka_carol_9axis_sheet.png & aka_carol_thumb.png
def load_inp_premult(path):
    b = open(path, 'rb').read()
    n = struct.unpack('>I', b[8:12])[0]
    j = json.loads(b[12:12+n].decode('utf-8'))
    o = 12 + n + 8
    cnt = struct.unpack('>I', b[o:o+4])[0]
    o += 4
    texs = []
    over_total = 0
    for i in range(cnt):
        L = struct.unpack('>I', b[o:o+4])[0]
        im = np.array(Image.open(io.BytesIO(b[o+5:o+5+L])).convert('RGBA'))
        texs.append(im)
        o += 5 + L
        a = im[..., 3]
        soft = (a >= 24) & (a <= 232)
        if soft.sum() > 0:
            over_total += int((im[..., :3].max(axis=-1)[soft] > (a[soft] + 6)).sum())
    print(f"Verified {os.path.basename(path)}: over_total = {over_total}")
    return j, texs

def cell_interp(pts, t):
    if len(pts) == 1: return 0, 0, 0.0
    for i in range(len(pts) - 1):
        if t <= pts[i + 1] or i == len(pts) - 2:
            span = pts[i + 1] - pts[i]
            return i, i + 1, (min(1.0, max(0.0, (t - pts[i]) / span)) if span > 0 else 0.0)
    return 0, 0, 0.0

def render_pose_premult(j, texs_premult, yaw_norm=0.5, pitch_norm=0.5, head_only=False):
    nodes = {}
    parts = []
    def walk(nd, parent_uuid=None):
        nd_c = dict(nd)
        nd_c['parent'] = parent_uuid
        nd_c['off_t'] = np.zeros(3, np.float64)
        nd_c['off_r'] = np.zeros(3, np.float64)
        nd_c['off_s'] = np.ones(2, np.float64)
        nd_c['off_z'] = 0.0
        nd_c['off_op'] = 1.0
        nd_c['deform'] = None
        nodes[nd['uuid']] = nd_c
        if nd.get('type') == 'Part': parts.append(nd_c)
        for c in nd.get('children', []): walk(c, nd['uuid'])
    walk(j['nodes'])

    for p in j['param']:
        val = list(p['defaults']) if isinstance(p['defaults'], list) else [p['defaults'], 0.0]
        pmin = list(p['min']) if isinstance(p['min'], list) else [p['min'], 0.0]
        pmax = list(p['max']) if isinstance(p['max'], list) else [p['max'], 1.0]
        if p['name'] == 'Head:: Yaw-Pitch': nx, ny = yaw_norm, pitch_norm
        else:
            nx = (val[0] - pmin[0]) / ((pmax[0] - pmin[0]) or 1.0)
            ny = (val[1] - pmin[1]) / ((pmax[1] - pmin[1]) or 1.0) if p.get('is_vec2') else 0.0
        ax = p.get('axis_points') or [[0.0, 1.0], [0.0]]
        x0, x1, wx = cell_interp(ax[0], nx)
        y0, y1, wy = cell_interp(ax[1] if len(ax) > 1 else [0.0], ny)
        w00, w10, w01, w11 = (1-wx)*(1-wy), wx*(1-wy), (1-wx)*wy, wx*wy
        for bd in p['bindings']:
            nd = nodes.get(bd['node'])
            if not nd: continue
            V = bd['values']
            pname = bd['param_name']
            if pname == 'deform':
                a, c, d, e = np.array(V[x0][y0], np.float32), np.array(V[x1][y0], np.float32), np.array(V[x0][y1], np.float32), np.array(V[x1][y1], np.float32)
                if a.size == 0: continue
                if nd['deform'] is None: nd['deform'] = np.zeros_like(a)
                nd['deform'] += w00 * a + w10 * c + w01 * d + w11 * e
            else:
                v = w00 * V[x0][y0] + w10 * V[x1][y0] + w01 * V[x0][y1] + w11 * V[x1][y1]
                if pname == 'transform.t.x': nd['off_t'][0] += v
                elif pname == 'transform.t.y': nd['off_t'][1] += v
                elif pname == 'transform.t.z': nd['off_t'][2] += v
                elif pname == 'transform.r.z': nd['off_r'][2] += v
                elif pname == 'transform.s.x': nd['off_s'][0] *= v
                elif pname == 'transform.s.y': nd['off_s'][1] *= v
                elif pname == 'zSort': nd['off_z'] += v
                elif pname == 'opacity': nd['off_op'] *= v

    def trs_mat(t, r, s):
        cz, sz = math.cos(r[2]), math.sin(r[2])
        return np.array([[cz*s[0], -sz*s[1], t[0]], [sz*s[0], cz*s[1], t[1]], [0.0, 0.0, 1.0]], np.float64)

    def calc_world(nd, M, z):
        t = np.array(nd['transform']['trans'], np.float64) + nd['off_t']
        r = np.array(nd['transform']['rot'], np.float64) + nd['off_r']
        s = np.array(nd['transform']['scale'], np.float64) * nd['off_s']
        nd['M'] = M @ trs_mat(t, r, s)
        nd['wz'] = z + (nd.get('zsort') or 0.0) + nd['off_z']
        nd['wop'] = (nd.get('opacity') if nd.get('opacity') is not None else 1.0) * nd['off_op']
        for c in nd.get('children', []): calc_world(nodes[c['uuid']], nd['M'], nd['wz'])

    calc_world(nodes[j['nodes']['uuid']], np.eye(3), 0.0)

    if head_only:
        vx0, vy0, vx1, vy1 = -820.0, -2500.0, 680.0, -1000.0
        scale = 0.36
    else:
        vx0, vy0, vx1, vy1 = -1350.0, -2550.0, 1200.0, 2550.0
        scale = 0.22

    W = int(round((vx1 - vx0) * scale))
    H = int(round((vy1 - vy0) * scale))
    acc = np.zeros((H, W, 4), np.float32)

    def rasterize_part_to_buffer(nd):
        tid = nd['textures'][0]
        tex = texs_premult[tid]
        th, tw, _ = tex.shape
        if th <= 16 and tw <= 16 and tex[..., 3].max() == 0: return None
        v = np.array(nd['mesh']['verts'], np.float32).reshape(-1, 2)
        if nd['deform'] is not None and len(nd['deform']) == len(v): v = v + nd['deform']
        ones = np.ones((len(v), 1), np.float32)
        vw = (nd['M'] @ np.hstack([v, ones]).T).T[:, :2]
        pts_dst = np.column_stack([(vw[:, 0] - vx0) * scale, (vw[:, 1] - vy0) * scale]).astype(np.float32)
        uv = np.array(nd['mesh']['uvs'], np.float32).reshape(-1, 2)
        pts_src = np.column_stack([uv[:, 0] * tw, uv[:, 1] * th]).astype(np.float32)
        indices = np.array(nd['mesh']['indices'], np.int32).reshape(-1, 3)

        layer = np.zeros((H, W, 4), np.float32)
        tex_f = tex.astype(np.float32) / 255.0
        for tri in indices:
            s_tri = pts_src[tri]
            d_tri = pts_dst[tri]
            x0 = max(0, int(math.floor(d_tri[:, 0].min())))
            x1 = min(W, int(math.ceil(d_tri[:, 0].max())) + 1)
            y0 = max(0, int(math.floor(d_tri[:, 1].min())))
            y1 = min(H, int(math.ceil(d_tri[:, 1].max())) + 1)
            if x1 <= x0 or y1 <= y0: continue
            sx0 = max(0, int(math.floor(s_tri[:, 0].min())) - 1)
            sx1 = min(tw, int(math.ceil(s_tri[:, 0].max())) + 2)
            sy0 = max(0, int(math.floor(s_tri[:, 1].min())) - 1)
            sy1 = min(th, int(math.ceil(s_tri[:, 1].max())) + 2)
            if sx1 <= sx0 or sy1 <= sy0: continue
            M_aff = cv2.getAffineTransform(s_tri - np.array([sx0, sy0], np.float32), d_tri - np.array([x0, y0], np.float32))
            warped = cv2.warpAffine(tex_f[sy0:sy1, sx0:sx1], M_aff, (x1 - x0, y1 - y0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=(0,0,0,0))
            t_mask = np.zeros((y1 - y0, x1 - x0), np.uint8)
            # Use non-antialiased LINE_8 polygon fill inside the mesh so shared triangle edges have zero seam lines!
            cv2.fillConvexPoly(t_mask, np.round(d_tri - np.array([x0, y0])).astype(np.int32), 255, lineType=cv2.LINE_8)
            m_f = (t_mask > 0)[..., None]
            layer[y0:y1, x0:x1] = np.where(m_f, warped, layer[y0:y1, x0:x1])
        return layer * float(nd['wop'])

    part_order = sorted(parts, key=lambda x: x['wz'], reverse=True)
    cached_layers = {}
    for nd in part_order:
        if nd['wop'] <= 0.01: continue
        lyr = rasterize_part_to_buffer(nd)
        if lyr is None: continue
        cached_layers[nd['uuid']] = lyr
        masks = nd.get('masks') or []
        if masks:
            mask_acc = np.zeros((H, W), np.float32)
            for m in masks:
                src_uid = m['source']
                if src_uid not in cached_layers:
                    src_nd = nodes.get(src_uid)
                    if src_nd and src_nd.get('type') == 'Part': cached_layers[src_uid] = rasterize_part_to_buffer(src_nd)
                src_lyr = cached_layers.get(src_uid)
                if src_lyr is not None:
                    thr = m.get('mask_threshold', 0.5)
                    if m.get('mode') == 'DodgeMask': mask_acc = np.where(src_lyr[..., 3] > thr, 0.0, mask_acc)
                    else: mask_acc = np.where(src_lyr[..., 3] > thr, 1.0, mask_acc)
            lyr = lyr * mask_acc[..., None]

        bmode = nd.get('blend_mode', 'Normal')
        sa, srgb = lyr[..., 3:4], lyr[..., :3]
        da, drgb = acc[..., 3:4], acc[..., :3]
        if bmode == 'ClipToLower':
            acc[..., :3] = srgb * da + drgb * (1.0 - sa)
        elif bmode == 'Multiply':
            acc[..., :3] = srgb * drgb + drgb * (1.0 - sa)
            acc[..., 3:4] = sa * da + da * (1.0 - sa) if masks else (sa + da * (1.0 - sa))
        else:
            acc[..., :3] = srgb + drgb * (1.0 - sa)
            acc[..., 3:4] = sa + da * (1.0 - sa)

    bg = np.array([247.0, 239.0, 232.0], np.float32) / 255.0
    out_rgb = np.clip((acc[..., :3] + bg * (1.0 - acc[..., 3:4])) * 255.0, 0, 255).astype(np.uint8)
    a_out = np.clip(acc[..., 3:4], 0, 1)
    s_rgb = np.where(a_out > 1e-4, np.clip(acc[..., :3] / np.maximum(1e-4, a_out), 0, 1), 0)
    out_rgba = np.dstack([(s_rgb * 255).round().astype(np.uint8), (a_out[..., 0] * 255).round().astype(np.uint8)])
    return Image.fromarray(out_rgb, 'RGB'), Image.fromarray(out_rgba, 'RGBA')

j_orig, texs_orig = load_inp_premult(AKA_INP)
j_carol_chk, texs_carol_chk = load_inp_premult(out_inp_path)
if os.path.exists(os.path.join(OUT_DIR, 'aka_gemini.inp')):
    load_inp_premult(os.path.join(OUT_DIR, 'aka_gemini.inp'))

orig_full, _ = render_pose_premult(j_orig, texs_orig, 0.5, 0.5, head_only=False)
carol_full, carol_rgba = render_pose_premult(j_carol_chk, texs_carol_chk, 0.5, 0.5, head_only=False)

thumb = Image.new('RGBA', (460, 680), (247, 239, 232, 255))
cf_copy = carol_rgba.copy()
cf_copy.thumbnail((430, 650), Image.LANCZOS)
thumb.alpha_composite(cf_copy, ((460 - cf_copy.width)//2, (680 - cf_copy.height)//2))
thumb.save(os.path.join(OUT_DIR, 'aka_carol_thumb.png'))

grid_angles = [
    (0.0, 1.0), (0.5, 1.0), (1.0, 1.0),
    (0.0, 0.5), (0.5, 0.5), (1.0, 0.5),
    (0.0, 0.0), (0.5, 0.0), (1.0, 0.0),
]
cells = [render_pose_premult(j_carol_chk, texs_carol_chk, yn, pn, head_only=True)[0] for yn, pn in grid_angles]
cw, ch = cells[0].size
sheet_w = orig_full.width + carol_full.width + cw * 3 + 60
sheet_h = max(orig_full.height + 40, ch * 3 + 40)
sheet = Image.new('RGB', (sheet_w, sheet_h), (247, 239, 232))
sheet.paste(orig_full, (15, 20))
sheet.paste(carol_full, (15 + orig_full.width + 15, 20))
ox = 15 + orig_full.width + 15 + carol_full.width + 15
for idx, cell_im in enumerate(cells):
    r, c = idx // 3, idx % 3
    sheet.paste(cell_im, (ox + c * cw, 20 + r * ch))

sheet_path = os.path.join(OUT_DIR, 'aka_carol_9axis_sheet.png')
sheet.save(sheet_path)
print("Saved spotless aka_carol_9axis_sheet.png:", sheet.size)

# Repack aka_carol_psd_and_inp_pack.zip
pack_path = os.path.join(OUT_DIR, 'aka_carol_psd_and_inp_pack.zip')
with zipfile.ZipFile(pack_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    zf.write(out_inp_path, 'aka_carol.inp')
    if os.path.exists(os.path.join(CAROL_DIR, 'aka_carol_layers.psd')):
        zf.write(os.path.join(CAROL_DIR, 'aka_carol_layers.psd'), 'aka_carol_layers.psd')
    zf.write(os.path.join(CAROL_DIR, 'carol_character_white_bg.jpg'), 'carol_character_white_bg.jpg')
    zf.write(os.path.join(CAROL_DIR, 'carol_hair_parts_white_bg.jpg'), 'carol_hair_parts_white_bg.jpg')
    zf.write(os.path.join(CAROL_DIR, 'carol_body_parts_white_bg.jpg'), 'carol_body_parts_white_bg.jpg')
    zf.write(os.path.join(OUT_DIR, 'build_aka_carol.py'), 'build_aka_carol.py')
print("Saved pack:", pack_path, os.path.getsize(pack_path) // 1024, "KB")
