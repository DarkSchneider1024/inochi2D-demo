# -*- coding: utf-8 -*-
import io, json, math, os, struct
import cv2
import numpy as np
from PIL import Image

WORK = '/working_dir/c_049b8b64f4523031'
GEN_DIR = os.path.join(WORK, 'user_uploaded_files/ttl=63d/tool_generated')
AKA_INP = os.path.join(WORK, 'downloads/aka.inp')
OUT_DIR = os.path.join(WORK, 'output_drive')
DEMO_DIR = os.path.join(WORK, 'demo_build')

HAIR_SHEET = os.path.join(GEN_DIR, 'watermarked_img_1799372624906120723.jpg')
BODY_SHEET = os.path.join(GEN_DIR, 'watermarked_img_1900760381899220685.jpg')

def extract_components_white_bg(img_path, min_area=800):
    im = Image.open(img_path).convert('RGB')
    arr = np.array(im)
    H, W, _ = arr.shape
    non_white = (arr.min(axis=-1) < 242) | ((255 - arr).max(axis=-1) > 15)
    closed = cv2.morphologyEx(non_white.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    num, labels, stats, centroids = cv2.connectedComponentsWithStats(closed, connectivity=8)
    comps = []
    for i in range(1, num):
        x, y, w, h, area = stats[i]
        if area < min_area:
            continue
        pad = 12
        x0, y0 = max(0, x - pad), max(0, y - pad)
        x1, y1 = min(W, x + w + pad), min(H, y + h + pad)
        crop_rgb = arr[y0:y1, x0:x1].copy()
        ch, cw, _ = crop_rgb.shape
        bg_cand = ((crop_rgb.min(axis=-1) > 238) & ((crop_rgb.max(axis=-1) - crop_rgb.min(axis=-1)) < 18)).astype(np.uint8)
        n_bg, l_bg = cv2.connectedComponents(bg_cand, connectivity=4)
        border_labels = set(l_bg[0, :]) | set(l_bg[-1, :]) | set(l_bg[:, 0]) | set(l_bg[:, -1])
        border_labels.discard(0)
        ext_mask = np.isin(l_bg, list(border_labels))
        alpha = (~ext_mask).astype(np.float32) * 255.0
        dist = cv2.distanceTransform((~ext_mask).astype(np.uint8), cv2.DIST_L2, 3)
        rim = (dist > 0) & (dist <= 1.8)
        lum = crop_rgb.mean(axis=-1)
        alpha[rim] = np.clip((252.0 - lum[rim]) / 45.0, 0.15, 1.0) * 255.0
        rgba = np.dstack([crop_rgb, alpha.astype(np.uint8)])
        comps.append({
            'box': (x, y, w, h),
            'center': (centroids[i][0], centroids[i][1]),
            'rgba': Image.fromarray(rgba, 'RGBA')
        })
    comps.sort(key=lambda c: (int(c['box'][1] // 300), c['box'][0]))
    return comps

def recolor_shadow_or_light(aka_pil, rgb_color):
    arr = np.array(aka_pil.convert('RGBA')).astype(np.float32)
    lum = (arr[..., 0] * 0.299 + arr[..., 1] * 0.587 + arr[..., 2] * 0.114) / 255.0
    out = np.zeros_like(arr)
    for c in range(3):
        out[..., c] = np.clip(rgb_color[c] * (0.75 + 0.35 * lum), 0, 255)
    out[..., 3] = arr[..., 3]
    return Image.fromarray(out.astype(np.uint8), 'RGBA')

hair_comps = extract_components_white_bg(HAIR_SHEET)
body_comps = extract_components_white_bg(BODY_SHEET)

def morph_gem_smooth(gem_pil, aka_pil, axis='y', trim_border_px=0, blend_orig_detail=0.35):
    aka_arr = np.array(aka_pil.convert('RGBA')).astype(np.float32)
    gem_arr = np.array(gem_pil.convert('RGBA')).astype(np.float32)

    ga = gem_arr[..., 3] > 24
    if trim_border_px > 0:
        eroded = cv2.erode(ga.astype(np.uint8), np.ones((trim_border_px*2+1, trim_border_px*2+1), np.uint8)) > 0
        if eroded.any():
            ga = eroded

    gy, gx = np.nonzero(ga)
    gem_crop = gem_arr[gy.min():gy.max()+1, gx.min():gx.max()+1]
    gh, gw, _ = gem_crop.shape
    ga_crop = ga[gy.min():gy.max()+1, gx.min():gx.max()+1]

    valid_mask = (ga_crop).astype(np.uint8)
    gem_rgb_clean = gem_crop[..., :3].astype(np.uint8)
    if (valid_mask == 0).any():
        gem_rgb_clean = cv2.inpaint(gem_rgb_clean, 1 - valid_mask, 5, cv2.INPAINT_TELEA)
    gem_rgb_clean = cv2.GaussianBlur(gem_rgb_clean, (3, 3), 0.6).astype(np.float32)

    ah, aw, _ = aka_arr.shape
    aa = aka_arr[..., 3]
    ay, ax = np.nonzero(aa > 8)
    if len(ay) == 0:
        return aka_pil

    map_x = np.zeros((ah, aw), np.float32)
    map_y = np.zeros((ah, aw), np.float32)

    if axis == 'y':
        y_min, y_max = ay.min(), ay.max()
        span_y = max(1.0, float(y_max - y_min))
        gem_lr = np.zeros((gh, 2), np.float32)
        for r in range(gh):
            cols = np.nonzero(ga_crop[r])[0]
            if len(cols) > 0:
                gem_lr[r] = [cols[0], cols[-1]]
            else:
                gem_lr[r] = [gw * 0.1, gw * 0.9]
        kernel = np.ones(11, np.float32) / 11.0
        gem_l = np.convolve(gem_lr[:, 0], kernel, mode='same')
        gem_r = np.convolve(gem_lr[:, 1], kernel, mode='same')

        for r in range(y_min, y_max + 1):
            row_mask = aa[r] > 8
            if not row_mask.any():
                continue
            cols = np.nonzero(row_mask)[0]
            al, ar = float(cols[0]), float(cols[-1])
            aspan = max(1.0, ar - al)
            v = (r - y_min) / span_y
            gr_f = v * (gh - 1)
            gr_i = min(gh - 1, max(0, int(round(gr_f))))
            gl, gr_bound = gem_l[gr_i], max(gem_l[gr_i] + 1.0, gem_r[gr_i])
            gspan = gr_bound - gl

            xs = np.arange(aw, dtype=np.float32)
            u = np.clip((xs - al) / aspan, 0.0, 1.0)
            map_x[r, :] = gl + u * gspan
            map_y[r, :] = gr_f
    else:
        x_min, x_max = ax.min(), ax.max()
        span_x = max(1.0, float(x_max - x_min))
        gem_tb = np.zeros((gw, 2), np.float32)
        for c in range(gw):
            rows = np.nonzero(ga_crop[:, c])[0]
            if len(rows) > 0:
                gem_tb[c] = [rows[0], rows[-1]]
            else:
                gem_tb[c] = [gh * 0.1, gh * 0.9]
        kernel = np.ones(11, np.float32) / 11.0
        gem_t = np.convolve(gem_tb[:, 0], kernel, mode='same')
        gem_b = np.convolve(gem_tb[:, 1], kernel, mode='same')

        for c in range(x_min, x_max + 1):
            col_mask = aa[:, c] > 8
            if not col_mask.any():
                continue
            rows = np.nonzero(col_mask)[0]
            at, ab = float(rows[0]), float(rows[-1])
            aspan = max(1.0, ab - at)
            u = (c - x_min) / span_x
            gc_f = u * (gw - 1)
            gc_i = min(gw - 1, max(0, int(round(gc_f))))
            gt, gb_bound = gem_t[gc_i], max(gem_t[gc_i] + 1.0, gem_b[gc_i])
            gspan = gb_bound - gt

            ys = np.arange(ah, dtype=np.float32)
            v = np.clip((ys - at) / aspan, 0.0, 1.0)
            map_x[:, c] = gc_f
            map_y[:, c] = gt + v * gspan

    warped_rgb = cv2.remap(gem_rgb_clean, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)

    if blend_orig_detail > 0:
        orig_lum = (aka_arr[..., 0] * 0.299 + aka_arr[..., 1] * 0.587 + aka_arr[..., 2] * 0.114)
        valid = aa > 32
        med_lum = np.median(orig_lum[valid]) if valid.any() else 180.0
        ratio = np.clip(orig_lum / max(1.0, med_lum), 0.65, 1.22)[..., None]
        warped_rgb = np.clip(warped_rgb * ((1.0 - blend_orig_detail) + blend_orig_detail * ratio), 0, 255)

    out = np.zeros_like(aka_arr)
    out[..., :3] = warped_rgb
    out[..., 3] = aa
    return Image.fromarray(out.astype(np.uint8), 'RGBA')

b = open(AKA_INP, 'rb').read()
n = struct.unpack('>I', b[8:12])[0]
j = json.loads(b[12:12+n].decode('utf-8'))
o = 12 + n
cnt = struct.unpack('>I', b[o+8:o+12])[0]
o += 12
orig_texs = []
for i in range(cnt):
    L = struct.unpack('>I', b[o:o+4])[0]
    orig_texs.append(Image.open(io.BytesIO(b[o+5:o+5+L])).convert('RGBA'))
    o += 5 + L

new_texs = list(orig_texs)

hair_map = {
    65: (hair_comps[0]['rgba'], 'y', 5, 0.50),
    61: (hair_comps[1]['rgba'], 'y', 5, 0.50),
    63: (hair_comps[2]['rgba'], 'y', 5, 0.50),
    57: (hair_comps[3]['rgba'], 'y', 5, 0.50),
    59: (hair_comps[4]['rgba'], 'y', 5, 0.50),
    69: (hair_comps[5]['rgba'], 'x', 1, 0.20),
    55: (hair_comps[6]['rgba'], 'y', 4, 0.45),
    70: (hair_comps[7]['rgba'], 'y', 4, 0.45),
    52: (hair_comps[8]['rgba'], 'y', 2, 0.35),
    51: (hair_comps[9]['rgba'], 'y', 2, 0.35),
    45: (hair_comps[10]['rgba'], 'y', 6, 0.55),
    46: (hair_comps[10]['rgba'], 'y', 6, 0.55),
    47: (hair_comps[10]['rgba'], 'y', 6, 0.55),
    48: (hair_comps[10]['rgba'], 'y', 6, 0.55),
    49: (hair_comps[10]['rgba'], 'y', 6, 0.55),
    53: (hair_comps[10]['rgba'], 'y', 6, 0.55),
    54: (hair_comps[10]['rgba'], 'y', 6, 0.55),
}
for tid, (gem_im, ax_dir, trim_px, detail_w) in hair_map.items():
    new_texs[tid] = morph_gem_smooth(gem_im, orig_texs[tid], axis=ax_dir, trim_border_px=trim_px, blend_orig_detail=detail_w)

body_map = {
    5:  (body_comps[0]['rgba'], 'y', 1, 0.25),
    4:  (body_comps[1]['rgba'], 'y', 1, 0.25),
    0:  (body_comps[2]['rgba'], 'y', 1, 0.25),
    1:  (body_comps[3]['rgba'], 'x', 1, 0.25),
    3:  (body_comps[4]['rgba'], 'x', 2, 0.35),
    8:  (body_comps[5]['rgba'], 'y', 1, 0.25),
    6:  (body_comps[6]['rgba'], 'y', 1, 0.25),
    9:  (body_comps[7]['rgba'], 'y', 0, 0.15),
    7:  (body_comps[8]['rgba'], 'y', 0, 0.15),
    74: (body_comps[9]['rgba'], 'y', 1, 0.25),
    72: (body_comps[10]['rgba'], 'y', 1, 0.25),
}
for tid, (gem_im, ax_dir, trim_px, detail_w) in body_map.items():
    new_texs[tid] = morph_gem_smooth(gem_im, orig_texs[tid], axis=ax_dir, trim_border_px=trim_px, blend_orig_detail=detail_w)

for tid in [56, 58, 60, 62, 64, 66, 71]:
    new_texs[tid] = recolor_shadow_or_light(orig_texs[tid], (245, 242, 255))
for tid in [13, 14, 15, 16, 17, 18, 19]:
    new_texs[tid] = recolor_shadow_or_light(orig_texs[tid], (222, 196, 204))
for tid in [50]:
    arr50 = np.array(recolor_shadow_or_light(orig_texs[50], (140, 130, 175)))
    arr50[..., 3] = (arr50[..., 3].astype(np.float32) * 0.45).astype(np.uint8)
    new_texs[50] = Image.fromarray(arr50, 'RGBA')
for tid in [2, 73, 75]:
    new_texs[tid] = recolor_shadow_or_light(orig_texs[tid], (165, 160, 195))

j['meta']['name'] = 'Aka (Gemini 九軸換裝角色)'
j['meta']['version'] = '2026-11-05-gemini'
js_bytes = json.dumps(j, ensure_ascii=False).encode('utf-8')

out_chunks = [b'TRNSRTS\x00', struct.pack('>I', len(js_bytes)), js_bytes, b'TEX_SECT', struct.pack('>I', len(new_texs))]
for im in new_texs:
    buf = io.BytesIO()
    im.save(buf, 'PNG', optimize=True)
    pdata = buf.getvalue()
    out_chunks += [struct.pack('>I', len(pdata)), b'\x00', pdata]

inp_bytes = b''.join(out_chunks)
for dst in [
    os.path.join(OUT_DIR, 'aka_gemini.inp'),
    os.path.join(OUT_DIR, 'aka_gemini.inx'),
    os.path.join(DEMO_DIR, 'models', 'aka_gemini.inp'),
    os.path.join(DEMO_DIR, 'models', 'aka_gemini.inx'),
]:
    with open(dst, 'wb') as f:
        f.write(inp_bytes)
print('Updated aka_gemini.inp/.inx successfully!')
