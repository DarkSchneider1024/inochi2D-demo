# 90° 九軸可編輯模型與素體包 (Live2D .cmo3 + Inochi2D .inp/.inx + 3D 頭骨位移表)

- 建置日期：2026-11-05
- 角度範圍：Yaw `-90° .. +90°`（9 段，每 22.5° 一格）× Pitch `-30° .. +30°`（3 段），共 27 個關鍵幀。

## 內含檔案

1. `kei_90deg_9axis_editable.cmo3`：Live2D Cubism 可編輯 90° 九軸工程檔（含 16 個九軸曲面變形器 `CWarpDeformerSource` 與 6 個頭部部件網格 `CArtMeshSource`，無框線 `脸` 與獨立 73 頂點共邊輪廓帶 `顔線`）。
2. `base_head_90deg_9axis.inp` / `base_head_90deg_9axis.inx`：Inochi2D v0.8.7 16 圖層分離光頭無髮素體（通過 T10 頭頂零形變審計 `crown_max_residual = 1e-6`、下巴中點對齊誤差 `0.096 px`、27 鍵 0 網格翻轉）。
3. `blender_head9_90deg.json`：由 `vroid_girl.blend` 3D 頭骨頂點座標計算之 90° 九軸（9×3）位移與縮放表。
4. `cmo3_kei_head9_90deg.json`：從 `kei_90deg_9axis_editable.cmo3` 提取之 90° 九軸變形器與網格座標 JSON。
5. `base_head_90deg_9axis_sheet.png`：5×3 角度（`-90°, -45°, 0°, +45°, +90°` × `+30°, 0°, -30°`）驗收預覽圖。
