"""Cache learned SAM masks; original artwork remains the source of visible pixels."""
from pathlib import Path
import sys, json
import numpy as np
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/claude5.5_live2d'))
from cv_models import Sam
ASSET=ROOT/'images/gpt_gold_mage'
OUT=ROOT/'output/gpt_gold_mage_v1'
SPEC={
 'hair':dict(box=(400,9,626,210),pos=[(506,65),(444,104),(579,106),(609,128)],neg=[(512,191),(482,170),(544,170)]),
 'head':dict(box=(443,100,581,249),pos=[(510,203),(486,190),(545,191),(513,132)],neg=[(509,289),(529,64)]),
 'arm_R':dict(box=(257,276,400,749),pos=[(365,317),(325,447),(296,577),(310,693)],neg=[(408,445),(389,638),(511,477)]),
 'arm_L':dict(box=(613,280,744,653),pos=[(671,341),(691,450),(702,523),(664,578)],neg=[(596,460),(594,663)]),
 'book':dict(box=(274,544,456,744),pos=[(383,600),(402,674),(355,727)],neg=[(305,684),(296,578),(433,515)]),
 'pouch':dict(box=(555,600,655,799),pos=[(599,666),(609,713),(624,774)],neg=[(658,619),(563,796),(602,583)]),
 'scarf':dict(box=(456,268,562,361),pos=[(510,291),(488,323),(536,327)],neg=[(512,368)]),
 'leg_R':dict(box=(241,566,516,1517),pos=[(434,815),(399,1110),(367,1290),(325,1445)],neg=[(263,1011),(571,1024),(361,695)]),
 'leg_L':dict(box=(507,566,839,1518),pos=[(589,817),(665,1135),(704,1325),(762,1448)],neg=[(806,1066),(458,1018),(603,663)]),
 'coat':dict(box=(49,268,972,1225),pos=[(240,962),(134,1110),(858,1078),(766,966),(526,1010)],neg=[(432,971),(638,978),(507,467)])
}
if __name__=='__main__':
 im=np.asarray(Image.open(ASSET/'reference.png').convert('RGB'))
 cache=ASSET/'masks';cache.mkdir(exist_ok=True)
 sam=None; tiles=[]
 for name,prompt in SPEC.items():
  path=cache/(name+'.png')
  if not path.exists():
   if sam is None: sam=Sam(im)
   mask=sam.mask(**prompt);Image.fromarray(mask.astype('uint8')*255).save(path)
  mask=np.asarray(Image.open(path))>0
  tile=Image.fromarray(np.where(mask[...,None],im,230).astype('uint8'));tile.thumbnail((256,384))
  ImageDraw.Draw(tile).text((5,5),name,fill='red');tiles.append(tile)
  print(name, int(mask.sum()),flush=True)
 sheet=Image.new('RGB',(256*6,410*2),'white')
 for i,t in enumerate(tiles):sheet.paste(t,((i%6)*256,(i//6)*410))
 sheet.save(OUT/'segmentation.png')
 (ASSET/'segmentation_prompts.json').write_text(json.dumps(SPEC,indent=2),encoding='utf-8')
