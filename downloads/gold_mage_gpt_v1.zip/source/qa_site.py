from pathlib import Path
import json,threading,http.server,functools
from playwright.sync_api import sync_playwright
SITE=Path('C:/Users/gueiw/.codex/worktrees/gold-mage-publish')
OUT=Path(__file__).resolve().parents[2]/'output/gpt_gold_mage_v1'
class Q(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Q,directory=str(SITE)))
threading.Thread(target=srv.serve_forever,daemon=True).start();errors=[];report={}
with sync_playwright() as p:
 browser=p.chromium.launch(channel='msedge')
 page=browser.new_page(viewport=dict(width=1440,height=960));page.on('pageerror',lambda e:errors.append(str(e)))
 url=f'http://127.0.0.1:{srv.server_port}/?model=gold_mage_gpt_v1'
 page.goto(url);page.wait_for_function('window.demo?.puppet?.parts?.length>0',timeout=60000)
 page.locator('#tTalk').check();page.evaluate('window.demo.frameAt(2)')
 report['parts']=page.evaluate('window.demo.puppet.parts.length')
 report['parameters']=page.evaluate('Object.keys(window.demo.puppet.byName).length')
 page.screenshot(path=str(OUT/'site_desktop.png'))
 page.set_viewport_size(dict(width=390,height=844));page.evaluate('async()=>{await new Promise(requestAnimationFrame);await new Promise(requestAnimationFrame);window.demo.frameAt(2.1)}');page.screenshot(path=str(OUT/'site_mobile.png'),full_page=True)
 report['mobile_horizontal_overflow']=page.evaluate('document.documentElement.scrollWidth > innerWidth')
 report['console_errors']=errors
 assert report['parts']==44 and report['parameters']==19
 assert not errors and not report['mobile_horizontal_overflow']
 (OUT/'site_validation.json').write_text(json.dumps(report,indent=2));print(report)
 browser.close()
srv.shutdown()
