from pathlib import Path
import json,io,base64,threading,http.server,functools,shutil
import numpy as np,cv2,math
from PIL import Image,ImageDraw
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'output/gpt_gold_mage_v1'
shutil.copy2(ROOT.parent/'inochi2D-demo/inochi-lite.js',OUT/'inochi-lite.js')
(OUT/'qa.html').write_text('''<!doctype html><meta charset="utf-8"><style>body{margin:0}canvas{display:block}</style><canvas id="c"></canvas><script type="module">
import {loadINP,Puppet,Renderer} from './inochi-lite.js';
const p=new Puppet(await loadINP('./gold_mage_gpt_v1.inp')), c=document.getElementById('c'),r=new Renderer(c);r.attach(p);
window.shot=(params,view,w=600,h=600)=>{c.width=w;c.height=h;for(const n of Object.values(p.byName))n.value=[...n.defaults];for(const [k,v] of Object.entries(params))p.set(k,...[].concat(v));p.update();r.draw(view);return c.toDataURL('image/png')};window.ready=true;
</script>''',encoding='utf-8')
class Q(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Q,directory=str(OUT)))
threading.Thread(target=srv.serve_forever,daemon=True).start()
errors=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(channel='msedge');pg=b.new_page();pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.goto(f'http://127.0.0.1:{srv.server_port}/qa.html');pg.wait_for_function('window.ready',timeout=60000)
 def shot(ps,view,w=600,h=600):
  url=pg.evaluate('a=>window.shot(...a)',[ps,view,w,h]);return Image.open(io.BytesIO(base64.b64decode(url.split(',')[1]))).convert('RGBA')
 rest=shot({},dict(cx=0,cy=0,scale=1),1024,1536);rest.save(OUT/'webgl_rest.png')
 a=np.asarray(rest).astype(float);ref=np.asarray(Image.open(OUT/'psd_composite.png')).astype(float)
 # Compare on white, matching the PSD/GIMP flattened validation.
 a=a[:,:,:3]*a[:,:,3:]/255+255-a[:,:,3:];ref=ref[:,:,:3]*ref[:,:,3:]/255+255-ref[:,:,3:]
 diff=np.abs(np.rint(a)-np.rint(ref));metrics=dict(webgl_max_diff=float(diff.max()),webgl_mean_diff=float(diff.mean()),console_errors=errors)
 def sheet(poses,name,view):
  out=Image.new('RGB',(1800,600*((len(poses)+2)//3)),(231,233,239))
  for i,(label,ps) in enumerate(poses):
   im=shot(ps,view);tile=Image.new('RGBA',im.size,(231,233,239,255));tile.alpha_composite(im);ImageDraw.Draw(tile).text((10,10),label,fill=(20,20,30));out.paste(tile.convert('RGB'),((i%3)*600,(i//3)*600))
  out.save(OUT/name)
 sheet([(f'yaw={x} pitch={y}',{'Head:: Yaw-Pitch':[x,y]}) for y in (-1,0,1) for x in (-1,0,1)],'head_9axis.png',dict(cx=0,cy=-606,scale=2.2))
 sheet([('Neutral',{}),('Smile eyes',{'Eye:: Left:: Blink':1,'Eye:: Right:: Blink':1}),('Wink + ah',{'Eye:: Right:: Blink':1,'Mouth:: Open':1}),('Ah',{'Mouth:: Open':1}),('Oh',{'Mouth:: Open':1,'Mouth:: Form':1}),('Turn + talk',{'Head:: Yaw-Pitch':[1,.6],'Mouth:: Open':1})],'expressions.png',dict(cx=0,cy=-596,scale=3))
 sheet([('Rest',{}),('Arms -1',{'Arm:: Right:: Swing':-1,'Arm:: Left:: Swing':-1}),('Arms +1',{'Arm:: Right:: Swing':1,'Arm:: Left:: Swing':1}),('Coat -1',{'Coat:: Sway':-1,'Body:: Angle X-Y':[-1,-1]}),('Coat +1',{'Coat:: Sway':1,'Body:: Angle X-Y':[1,1]}),('Full movement',{'Head:: Yaw-Pitch':[1,1],'Hair:: Sway':1,'Head:: Roll':1,'Arm:: Right:: Bend':1,'Arm:: Left:: Bend':1,'Pendant:: Sway':1})],'body_poses.png',dict(cx=0,cy=0,scale=.37))
 def defects(im):
  fg=(np.asarray(im)[:,:,3]>100).astype('uint8')
  n,lab,st,_=cv2.connectedComponentsWithStats(fg,8)
  components=sum(int(st[i,4])>=8 for i in range(1,n))
  head=fg[0:145,195:320]
  n,lab,st,_=cv2.connectedComponentsWithStats(1-head,8)
  holes=sum(st[i,4]>=5 and st[i,0]>0 and st[i,1]>0 and st[i,0]+st[i,2]<head.shape[1] and st[i,1]+st[i,3]<head.shape[0] for i in range(1,n))
  return int(components),int(holes)
 baseline=shot({},dict(cx=0,cy=0,scale=.5),512,768);bc,bh=defects(baseline)
 shake=[];contact=Image.new('RGB',(512*5,768*2),(255,0,180));badframes=[]
 for i in range(101):
  t=i/10;wave=math.sin(t*3.1);yaw=math.sin(t*4.3);pitch=math.cos(t*2.7)
  ps={'Head:: Yaw-Pitch':[yaw,pitch],'Head:: Roll':math.sin(t*2.3),'Hair:: Sway':wave,'Coat:: Sway':wave,'Pendant:: Sway':-wave,'Arm:: Right:: Swing':wave,'Arm:: Left:: Swing':-wave,'Body:: Angle X-Y':[yaw,pitch],'Mouth:: Open':max(0,math.sin(t*7)),'Eye:: Right:: Blink':max(0,math.cos(t*8)),'Eye:: Left:: Blink':max(0,math.cos(t*8))}
  im=shot(ps,dict(cx=0,cy=0,scale=.5),512,768);co,ho=defects(im)
  shake.append(dict(frame=i,seconds=t,extra_components=max(0,co-bc),extra_head_holes=max(0,ho-bh)))
  if co>bc or ho>bh:
   badframes.append(i)
   dest=OUT/'flagged';dest.mkdir(exist_ok=True)
   im.save(dest/(f'{i:03d}.png'))
   n,lab,st,_=cv2.connectedComponentsWithStats((np.asarray(im)[:,:,3]>100).astype('uint8'),8)
   boxes=[st[q].tolist() for q in range(1,n) if 8<=st[q,4]<2000]
   shake[-1]['small_components']=boxes
  if i%10==0 and i<100:
   tile=Image.new('RGBA',im.size,(255,0,180,255));tile.alpha_composite(im);ImageDraw.Draw(tile).text((8,8),str(t)+'s',fill='black');contact.paste(tile.convert('RGB'),((i//10%5)*512,(i//50)*768))
 metrics['shake_frames']=101;metrics['shake_fragment_frames']=sum(r['extra_components']>0 for r in shake);metrics['shake_hole_frames']=sum(r['extra_head_holes']>0 for r in shake)
 contact.save(OUT/'shake_contact.jpg',quality=90)
 (OUT/'shake_metrics.json').write_text(json.dumps(shake,indent=2))
 (OUT/'qa_metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8');print(metrics)
 b.close()
srv.shutdown()
