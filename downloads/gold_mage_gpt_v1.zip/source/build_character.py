"""Gold mage v1. Original pixels + SAM segmentation + imagegen hidden base.
Shared brush/PSD utilities and the established INP 0.8 runtime are reused.
Run from any directory. Regenerates only this new character's output directory.
"""
from pathlib import Path
import sys, json, math, io, struct, shutil
import numpy as np
import cv2
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src/claude5.5_live2d'))
import build, girl
from cv_models import lama
ASSET=ROOT/'images/gpt_gold_mage'; OUT=ROOT/'output/gpt_gold_mage_v1'
NAME='gold_mage_gpt_v1'; W,H=1024,1536
girl.W,girl.H=W,H
Y,X=np.mgrid[:H,:W]
src=np.asarray(Image.open(ASSET/'reference.png').convert('RGB'))
base=np.asarray(Image.open(ASSET/'hidden_base.png').convert('RGB').resize((W,H)))
nog=np.asarray(Image.open(ASSET/'no_glasses.png').convert('RGB').resize((W,H)))
def dil(m,n):return cv2.dilate(m.astype('uint8'),np.ones((2*n+1,2*n+1),'uint8'))>0
def clean(m,minarea=80,holes=True):
 n,l,s,_=cv2.connectedComponentsWithStats(m.astype('uint8'),8)
 m=np.isin(l,[i for i in range(1,n) if s[i,4]>=minarea]).astype('uint8')
 if holes:
  contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
  cv2.drawContours(m,contours,-1,1,-1)
 return m>0
fg=clean(src.min(2)<240,100,False)
# Fill tiny antialias gaps but preserve the true negative spaces around arms and legs.
fg=cv2.morphologyEx(fg.astype('uint8'),cv2.MORPH_CLOSE,np.ones((3,3),'uint8'))>0
masks={p.stem:clean(np.asarray(Image.open(p))>0) for p in (ASSET/'masks').glob('*.png')}
# White specular paint enclosed by the learned hair silhouette is paint, not background.
fg |= masks['hair']
masks['leg_R'] &= X<514
masks['leg_L'] &= X>=514
masks['coat'] &= Y>630
for k in masks:masks[k]=dil(masks[k],2)&fg
face_outline=np.zeros((H,W),'uint8')
cv2.fillPoly(face_outline,[np.array([(456,153),(457,184),(470,210),(491,229),(512,242),(535,226),(552,205),(568,181),(569,150),(562,114),(544,79),(512,66),(479,81),(461,112)],np.int32)],1)
face_outline=face_outline>0
masks['head']=face_outline&fg
masks['hair'] &= Y<215
# Priority ownership, nearest surrounding source pixels close coarse SAM boundaries.
order=['coat','leg_R','leg_L','arm_R','arm_L','book','pouch','scarf','head','hair']
owner=np.zeros((H,W),np.uint8)
for i,k in enumerate(order,1):owner[masks[k]]=i
# Assign fine edge pixels to the closest learned region; no detached fragments on the torso.
dh=cv2.distanceTransform((~masks['hair']).astype('uint8'),cv2.DIST_L2,3)
df=cv2.distanceTransform((~masks['head']).astype('uint8'),cv2.DIST_L2,3)
missing=(Y<215)&(owner==0)&fg
owner[missing&(dh<df)]=order.index('hair')+1
owner[missing&(dh>=df)]=order.index('head')+1
# The book's exposed lower spine beside the fingers belongs to the held prop.
owner[fg&(X>=269)&(X<283)&(Y>=688)&(Y<718)]=order.index('book')+1
rendered=[]; extras=[]; metadata={}
def put(name,mask,rgb=src,kind='body',group='Body',extra=False):
 if kind in ('body','hair'):mask=clean(mask>0,12,False)
 if not mask.any():return
 a=np.uint8(np.clip(mask,0,1)*255)
 rgba=np.dstack([rgb.astype('uint8'),a])
 im=Image.fromarray(rgba,'RGBA');bb=im.getbbox()
 if not bb:return
 im=im.crop(bb)
 rec=((group,),name,im,bb[0],bb[1])
 (extras if extra else rendered).append(rec);metadata[name]=kind
def own(k):return (owner==order.index(k)+1)&fg
def poly(points):
 m=np.zeros((H,W),'uint8');cv2.fillPoly(m,[np.array(points,np.int32)],1);return m>0
def box(x0,y0,x1,y1):return (X>=x0)&(X<x1)&(Y>=y0)&(Y<y1)
def ellipse(cx,cy,rx,ry):return ((X-cx)/rx)**2+((Y-cy)/ry)**2<=1
def cached_fill(key,rgb,mask):
 p=ASSET/(key+'.png')
 if p.exists():return np.asarray(Image.open(p).convert('RGB'))
 out=np.clip(lama(rgb,mask),0,255).astype('uint8');Image.fromarray(out).save(p);return out

# Rear coat: separate panels, with modest hidden overlap under the legs.
coat=own('coat'); coatfull=dil(coat,10)&fg&(Y>650)
coattex=cached_fill('coat_underfill',src,coatfull&~coat)
for side,test in [('R',X<470),('MID',(X>=470)&(X<570)),('L',X>=570)]:
 put('Coat_'+side,coatfull&test,coattex,'coat','Coat')
# Leg cuts overlap in image space and share exactly the same deformation field.
for side in ('R','L'):
 m=own('leg_'+side)
 for part,a,b in [('Thigh',560,1015),('Shin',1005,1325),('Boot',1315,1536)]:
  put(part+'_'+side,m&(Y>=a)&(Y<b),kind='leg_'+side,group='Legs')
torso=fg&(owner==0)
torso &= ~box(470,0,554,245)
torso &= Y>=220
torso &= ~((Y<245)&(src[:,:,0].astype(int)-src[:,:,2].astype(int)>60)&(src[:,:,1]>120))
ribbon=fg&box(422,205,475,248)
torso &= ~ribbon
put('Ribbon',ribbon,src,'body','RibbonBase')
neckmask=(ellipse(512,236,30,22)&(Y<251))|poly([(483,234),(541,234),(546,248),(533,261),(515,277),(493,257),(478,244)])
necktex=src.copy()
necktex[:]=[250,201,166]
for yy in range(202,285):necktex[yy]=src[max(245,yy),np.clip(np.arange(W),492,532)]
put('Neck',neckmask,necktex,'neck','NeckBase')
torsofull=torso|(dil(torso,12)&fg&(Y>265)&(Y<675))
ttex=cached_fill('torso_underfill_v5',src,(torsofull&~torso)&(Y>280))
put('Torso',torsofull,ttex)
collar=poly([(475,222),(467,251),(475,274),(486,264),(497,283),(507,274),(490,246),(485,233)])|poly([(549,224),(558,254),(549,279),(538,264),(526,281),(518,272),(534,246),(541,233)])
put('Collar',collar,src,'body','CollarBase')
# The neck goes up behind the jaw. The main coat never contains a second jaw outline.
# Arms and held book share a continuous elbow field so the grasp cannot separate.
for side in ('R','L'):
 m=own('arm_'+side)
 cuts=[('UpperArm',270,491),('Forearm',481,665),('Hand',655,755)] if side=='R' else [('UpperArm',270,490),('Forearm',480,598),('Hand',588,665)]
 for part,a,b in cuts:put(part+'_'+side,m&(Y>=a)&(Y<b),kind='arm_'+side,group='Arms')
put('Book',own('book'),kind='arm_R',group='Accessories')
put('Pouch',own('pouch')&(Y<735),kind='pouch',group='Accessories')
put('Pendant',own('pouch')&(Y>=730),kind='pendant',group='Accessories')
put('Scarf',own('scarf'),kind='scarf',group='Accessories')
# Back knot (at the left side of the neck) must follow the head.
knot=np.zeros((H,W),bool)

# Fully painted scalp from the generated hidden-base image, original jaw/skin outside features.
blank=cached_fill('base_without_nose',base,box(499,161,523,201))
# Align the complete blank head by its crown and chin, then retain its continuous painted skin.
aff=np.float32([[1,0,0],[0,178/170,64*(1-178/170)]])
face=cv2.warpAffine(blank,aff,(W,H),borderValue=(255,255,255))
skinbase=clean((face[:,:,0].astype(int)-face[:,:,2].astype(int)>25)&box(440,60,583,245),50)
jaw_limit=243-np.maximum(0,np.abs(X-512)-1)*.85
head=dil(skinbase,1)&(Y<=jaw_limit)
# Remove the hidden bald scalp outline; it is always underneath hair at rest.
put('Face',head,face,'face','Head')

# Thin frame copied from original source inside measured lens curves, not a rectangular patch.
gmask=np.zeros((H,W),'uint8')
cv2.polylines(gmask,[np.array([(458,165),(464,160),(484,159),(500,162),(505,169),(502,183),(495,187),(470,186),(464,180),(458,165)],np.int32)],False,1,3,cv2.LINE_AA)
cv2.polylines(gmask,[np.array([(522,166),(529,161),(551,159),(565,162),(564,177),(557,184),(535,187),(527,183),(522,166)],np.int32)],False,1,3,cv2.LINE_AA)
cv2.line(gmask,(504,171),(523,170),1,3)
gmask=(gmask>0)&(src.max(2)-src.min(2)<30)&(src.min(2)<180)&(src.min(2)>45)

for side,cx in [('R',484),('L',544)]:
 # Original eye pixels from the no-glasses edit, with skin-shaded lids preserved.
 eye=poly([(cx-21,164),(cx-14,159),(cx+6,159),(cx+19,164),(cx+14,176),(cx-11,179),(cx-20,173)])
 iris=ellipse(cx,169,8.5,8)&eye
 high=iris&(nog.min(2)>210)
 lash=eye&(nog.mean(2)<85)&~ellipse(cx,170,7,8)
 white=eye&~iris&~lash
 # Eye white hidden behind moving pupil is white, with original upper lid colour retained.
 whitefull=eye&~lash
 whitetex=nog.copy();whitetex[iris]=[252,242,221]
 put('EyeWhite_'+side,whitefull,whitetex,'feature','Eyes')
 put('Iris_'+side,iris,nog,'feature','Eyes')
 put('Highlight_'+side,high,nog,'feature','Eyes')
 put('Lash_'+side,lash,nog,'feature','Eyes')
 brow=poly([(465,147),(479,149),(498,156),(501,160),(481,155),(466,152)] if side=='R' else [(526,156),(546,149),(560,146),(560,151),(542,155),(525,161)])
 put('Brow_'+side,cv2.GaussianBlur(brow.astype('float32'),(0,0),.65),nog,'feature','Eyes')

put('Nose',cv2.GaussianBlur(box(503,181,522,203).astype('float32'),(0,0),1),nog,'feature','Head')
mouthmask=cv2.GaussianBlur(box(493,205,533,222).astype('float32'),(0,0),2)
put('MouthClosed',mouthmask,nog,'feature','Mouth')
# Hair: rooted spike mass and independent front locks with overlap at their roots.
hair=own('hair')
front=hair&(Y>91)&(X>441)&(X<591)
put('HairBack',hair,src,'hair','Hair')
put('HairFront_R',front&(X<517),src,'hair','Hair')
put('HairFront_L',front&(X>=517),src,'hair','Hair')
glass=Image.new('L',(W*4,H*4));gd=ImageDraw.Draw(glass)
paths=[[(458,165),(463,160),(483,159),(500,162),(505,169),(502,182),(496,186),(472,186),(465,181),(458,165)],[(522,166),(528,161),(550,159),(565,162),(564,176),(557,183),(536,186),(528,182),(522,166)],[(505,171),(512,170),(522,170)]]
for pts in paths:gd.line([(x*4,y*4) for x,y in pts],fill=255,width=4,joint='curve')
ga=np.asarray(glass.resize((W,H),Image.Resampling.LANCZOS))/255
grgb=np.zeros_like(src);grgb[:]=[108,117,111]
put('Glasses',ga,grgb,'glasses','HeadTop')

# Brush-like supersampled expression shapes; they are native drawn model assets.
def expression(name,drawfn,kind='feature'):
 im=Image.new('RGBA',(W*4,H*4));d=ImageDraw.Draw(im);drawfn(d)
 im=im.resize((W,H),Image.Resampling.LANCZOS);bb=im.getbbox()
 extras.append((('Expressions',),name,im.crop(bb),bb[0],bb[1]));metadata[name]=kind
for side,cx in [('R',484),('L',544)]:
 def closed(d,cx=cx):
  pts=[((cx+x)*4,(169-5*math.sin((x+17)/34*math.pi))*4) for x in np.linspace(-17,17,60)]
  d.line(pts,fill=(78,42,26,255),width=7)
 expression('EyeClosed_'+side,closed)
def mouth(d,round=False):
 if round:
  d.ellipse((505*4,209*4,520*4,226*4),fill=(86,35,28,255));d.ellipse((508*4,220*4,518*4,225*4),fill=(209,111,105,255))
 else:
  pts=[(497*4,210*4),(528*4,210*4),(524*4,220*4),(516*4,226*4),(508*4,225*4),(502*4,219*4)]
  d.polygon(pts,fill=(88,35,27,255));d.rectangle((500*4,211*4,525*4,214*4),fill=(255,242,216,255));d.ellipse((506*4,220*4,522*4,225*4),fill=(210,112,107,255))
expression('MouthAh',mouth)
expression('MouthOh',lambda d:mouth(d,True))

OUT.mkdir(exist_ok=True)
merged=build.composite(rendered)
merged.save(OUT/'psd_composite.png')
prev=Image.new('RGBA',(W,H),(239,237,231,255));prev.alpha_composite(merged);prev.convert('RGB').save(OUT/'preview.jpg',quality=94)
build.contact_sheet(rendered+extras,str(OUT/'parts.png'),cols=7,cell=180)
comparison=Image.new('RGB',(W*2,H),'white');comparison.paste(Image.fromarray(src),(0,0));comparison.paste(merged,(W,0),merged);comparison.save(OUT/'comparison.jpg',quality=94)
comparison.crop((420,90,590,240)).resize((680,600)).save(OUT/'reference_face.png')
prev.crop((420,90,590,240)).resize((680,600)).save(OUT/'model_face.png')

# PSD master at 3072x4608. Upscaling does not invent detail; web model stays at source resolution.
def save_psd(recs,path,scale=3):
 girl.W,girl.H=W*scale,H*scale
 big=[(g,n,im.resize((im.width*scale,im.height*scale),Image.Resampling.BICUBIC),x*scale,y*scale) for g,n,im,x,y in recs]
 comp=build.composite(big);build.write_psd(big,str(path),comp)
 comp.save(path.with_suffix('.png'));girl.W,girl.H=W,H
save_psd(rendered,OUT/(NAME+'.psd'))
save_psd(extras,OUT/(NAME+'_expressions.psd'))
(OUT/'layers.json').write_text(json.dumps([dict(name=n,group=g[0],x=x,y=y,w=im.width,h=im.height,kind=metadata[n]) for g,n,im,x,y in rendered+extras],indent=2),encoding='utf-8')

# INP format and grid construction follow src/inochi2d/make_puppet.py.
uid=1000
def ID():
 global uid;uid+=1;return uid
def node(n,typ='Node'):
 return dict(uuid=ID(),name=n,type=typ,enabled=True,zsort=0,transform=dict(trans=[0.,0.,0.],rot=[0.,0.,0.],scale=[1.,1.]),lockToRoot=False,children=[])
root=node('GoldMage');parts={};textures=[];points={}
allrecs=rendered+extras
for i,(g,n,im,x,y) in enumerate(allrecs):
 p=node(n,'Part');p['zsort']=len(allrecs)-i
 b=io.BytesIO();im.save(b,'PNG');textures.append(b.getvalue())
 cols=max(2,math.ceil(im.width/16));rows=max(2,math.ceil(im.height/22))
 vv=[];uv=[];ix=[];world=[]
 for r in range(rows+1):
  for c in range(cols+1):
   u,v=c/cols,r/rows;xx,yy=x+im.width*u,y+im.height*v
   vv.extend([xx-W/2,yy-H/2]);uv.extend([u,v]);world.append((xx,yy))
 for r in range(rows):
  for c in range(cols):
   a=r*(cols+1)+c;ix.extend([a,a+cols+1,a+1,a+1,a+cols+1,a+cols+2])
 p.update(mesh=dict(verts=vv,uvs=uv,indices=ix,origin=[0,0]),textures=[i,4294967295,4294967295],blend_mode='Normal',tint=[1,1,1],screenTint=[0,0,0],emissionStrength=0.,mask_threshold=.5,opacity=1.)
 root['children'].append(p);parts[n]=p;points[n]=world
params=[]
def bind(n,prop,values):return dict(node=parts[n]['uuid'],param_name=prop,values=values,isSet=[[True]*len(r) for r in values],interpolate_mode='Linear')
def param(name,bindings,lo=-1,hi=1,axes=None,vec=False):
 params.append(dict(uuid=ID(),name=name,is_vec2=vec,min=[lo,lo if vec else 0],max=[hi,hi if vec else 1],defaults=[0,0],axis_points=axes or [[0,.5,1],[0]],merge_mode='Additive',bindings=bindings))
def deform(n,fn):return [[float(a),float(b)] for a,b in (fn(x,y) for x,y in points[n])]
def smooth(t):t=max(0,min(1,t));return t*t*(3-2*t)
def rotate(x,y,cx,cy,angle,weight=1):
 a=angle*weight;dx=x-cx;dy=y-cy;return (dx*math.cos(a)-dy*math.sin(a)-dx,dx*math.sin(a)+dy*math.cos(a)-dy)
headnames=[n for n in parts if metadata[n] in ('face','feature','hair','glasses','neck')]
def head_delta(n,x,y,k,l):
 kind=metadata[n];cx,cy=512,164;ha,hb=62,89
 # Full head translation + ellipsoid projection, including corner poses.
 u=(x-cx)/ha;v=(y-cy)/hb
 z=math.sqrt(max(0,1-min(.98,u*u+v*v)))*31
 if kind in ('feature','glasses'):z=27+math.sqrt(max(0,1-min(.98,u*u+v*v)))*9
 if kind=='hair':z+=5
 yaw=k*math.pi/12;pitch=l*math.pi/18
 dx=(x-cx)*(math.cos(yaw)-1)+z*math.sin(yaw)+10*k
 zz=z*math.cos(yaw)-(x-cx)*math.sin(yaw)
 dy=(y-cy)*(math.cos(pitch)-1)-zz*math.sin(pitch)+5*l
 if kind=='neck':
  weight=smooth((254-y)/28);dx*=weight;dy*=weight
 return dx,dy
param('Head:: Yaw-Pitch',[bind(n,'deform',[[deform(n,lambda x,y,k=k,l=l:head_delta(n,x,y,k,l)) for l in (-1,0,1)] for k in (-1,0,1)]) for n in headnames],vec=True,axes=[[0,.5,1],[0,.5,1]])
param('Head:: Roll',[bind(n,'deform',[[deform(n,lambda x,y,k=k:rotate(x,y,512,252,k*.10, smooth((280-y)/55) if metadata[n]=='neck' else 1))] for k in (-1,0,1)]) for n in headnames])
for side,label,cx in [('R','Right',484),('L','Left',544)]:
 bs=[]
 for prefix in ('EyeWhite','Iris','Highlight','Lash'):
  n=prefix+'_'+side
  bs += [bind(n,'opacity',[[1],[1],[0]]),bind(n,'deform',[[deform(n,lambda x,y,k=k:(0,(174-y)*.65*k))] for k in (0,.6,1)])]
 bs.append(bind('EyeClosed_'+side,'opacity',[[0],[0],[1]]))
 param('Eye:: '+label+':: Blink',bs,0,1,[[0,.6,1],[0]])
param('Mouth:: Open',[bind('MouthClosed','opacity',[[1],[0],[0]])]+[bind(n,'opacity',[[0],[1],[1]]) for n in ('MouthAh','MouthOh')]+[bind(n,'deform',[[deform(n,lambda x,y,k=k:((x-512)*(-.12*(1-k)),(y-210)*(-.80*(1-k))))] for k in (0,.3,1)]) for n in ('MouthAh','MouthOh')],0,1,[[0,.3,1],[0]])
param('Mouth:: Form',[bind('MouthAh','opacity',[[1],[0]]),bind('MouthOh','opacity',[[0],[1]])],0,1,[[0,1],[0]])
param('Brow:: Raise',[bind(n,'deform',[[deform(n,lambda x,y,k=k:(0,-3*k))] for k in (-1,0,1)]) for n in parts if n.startswith('Brow_')])
param('Eye:: Gaze',[bind(n,'deform',[[deform(n,lambda x,y,k=k,l=l:(2*k,1.2*l)) for l in (-1,0,1)] for k in (-1,0,1)]) for n in parts if n.startswith(('Iris_','Highlight_'))],vec=True,axes=[[0,.5,1],[0,.5,1]])
param('Body:: Breath',[bind(n,'deform',[[deform(n,lambda x,y:(0,0))],[deform(n,lambda x,y:((x-512)*.004*smooth((700-y)/420),-2.8*smooth((740-y)/450)))]] ) for n in parts],0,1,[[0,1],[0]])
param('Body:: Angle X-Y',[bind(n,'deform',[[deform(n,lambda x,y,k=k,l=l:((9*k+(x-512)*(math.cos(k*.09)-1))*smooth((1100-y)/700),-3*l*smooth((1100-y)/700))) for l in (-1,0,1)] for k in (-1,0,1)]) for n in parts],vec=True,axes=[[0,.5,1],[0,.5,1]])
param('Hair:: Sway',[bind(n,'deform',[[deform(n,lambda x,y,k=k,n=n:rotate(x,y,512,97,k*.025,smooth(abs(y-97)/90)))] for k in (-1,0,1)]) for n in parts if metadata[n]=='hair']+[bind(n,'deform',[[deform(n,lambda x,y,k=k,n=n:(k*3*smooth((y-290)/65),0))] for k in (-1,0,1)]) for n in parts if metadata[n]=='scarf'])
for side,label,cx,cy,sign in [('R','Right',317,487,1),('L','Left',703,502,-1)]:
 ns=[n for n in parts if metadata[n]=='arm_'+side]
 param('Arm:: '+label+':: Swing',[bind(n,'deform',[[deform(n,lambda x,y,k=k:rotate(x,y,cx,cy,k*.025*sign,smooth((y-cy+25)/110)))] for k in (-1,0,1)]) for n in ns])
 param('Arm:: '+label+':: Bend',[bind(n,'deform',[[deform(n,lambda x,y:(0,0))],[deform(n,lambda x,y:rotate(x,y,cx,cy,.045*sign,smooth((y-cy+25)/110)))]] ) for n in ns],0,1,[[0,1],[0]])
param('Coat:: Sway',[bind(n,'deform',[[deform(n,lambda x,y,k=k:(k*10*smooth((y-650)/570),0))] for k in (-1,0,1)]) for n in parts if metadata[n]=='coat'])
param('Pendant:: Sway',[bind('Pendant','deform',[[deform('Pendant',lambda x,y,k=k:rotate(x,y,618,730,k*.20))] for k in (-1,0,1)])])
for side,label in [('R','Right'),('L','Left')]:
 param('Leg:: '+label+':: Step',[bind(n,'deform',[[deform(n,lambda x,y:(0,0))],[deform(n,lambda x,y:(0,-6*smooth((y-680)/450)))]] ) for n in parts if metadata[n]=='leg_'+side],0,1,[[0,1],[0]])
puppet=dict(meta=dict(name=NAME,version='1.0',rigger='Codex',artist='User reference; OpenAI imagegen hidden bases',copyright='Carrot Studio',licenseURL=None,contact=None,reference=None,thumbnailId=4294967295,preservePixels=False),physics=dict(pixelsPerMeter=1000.,gravity=9.8),nodes=root,param=params,automation=[],animations={})
js=json.dumps(puppet,ensure_ascii=False,separators=(',',':')).encode()
data=b'TRNSRTS\0'+struct.pack('>I',len(js))+js+b'TEX_SECT'+struct.pack('>I',len(textures))
for t in textures:data+=struct.pack('>I',len(t))+b'\0'+t
(OUT/(NAME+'.inp')).write_bytes(data);(OUT/(NAME+'.inx')).write_bytes(data)
(OUT/'puppet.json').write_text(json.dumps(puppet,ensure_ascii=False),encoding='utf-8')
print('DONE',len(rendered),'base layers',len(extras),'expressions',len(params),'parameters',len(data),'bytes',flush=True)
